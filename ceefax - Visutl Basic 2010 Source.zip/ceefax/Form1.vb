﻿'Imports System.Web, System.Text, System
Imports System.Net, System.Net.Sockets
Imports System.IO
Imports System.Text
Imports System.Text.RegularExpressions
Imports ceefax.FastPixel

Public Class Form1
    Dim teefaxserver As String = "http://teastop.plus.com/svn/teletext/"
    ' Dim teefaxserver As String = "http://192.168.2.15/teletext/"

    Dim pb As New PictureBox
    Dim img As New Bitmap(480, 500, Drawing.Imaging.PixelFormat.Format24bppRgb)
    Dim rawfont As New Bitmap(My.Application.Info.DirectoryPath & "/mode7_hi.png")
    Dim fp_screen As New FastPixel(img)
    Dim fp_font As New FastPixel(rawfont)

    Dim thedata As String
    Dim nextpage As Integer = 0
    Dim searchpage As String = "100"
    Dim currentpage As String = ""
    Dim subpage As Integer = 0
    Dim pagedata As String = ""
    Dim pagelist As String = ""
    Dim redpage As String = ""
    Dim greenpage As String = ""
    Dim yellowpage As String = ""
    Dim bluepage As String = ""
    Dim startpos As Integer
    Dim endpos As Integer
    Dim filedirectory As String = ""
    Dim skipline As Integer = -1
    Dim reveal As Integer = 0
    Dim flash As Integer = 0

    Sub addchar(ByVal x As Integer, ByVal y As Integer, ByVal thechar As Integer, ByVal thebackcolor As Color, ByVal theforecolor As Color, ByVal doubleheight As Integer)
        If x < 40 And y < 25 Then
            Dim fontx As Integer = 0
            Dim fonty As Integer = 0

            If thechar >= 32 And thechar < 64 Then fontx = thechar - 32 : fonty = 0
            If thechar >= 64 And thechar < 96 Then fontx = thechar - 64 : fonty = 1
            If thechar >= 96 And thechar < 128 Then fontx = thechar - 96 : fonty = 2
            If thechar >= 128 And thechar < 160 Then fontx = thechar - 128 : fonty = 3
            If thechar >= 160 And thechar < 192 Then fontx = thechar - 160 : fonty = 4
            If thechar >= 192 And thechar < 224 Then fontx = thechar - 192 : fonty = 5
            If thechar >= 224 And thechar < 256 Then fontx = thechar - 224 : fonty = 6
            If thechar >= 256 And thechar < 288 Then fontx = thechar - 256 : fonty = 7
            If thechar >= 288 And thechar < 320 Then fontx = thechar - 288 : fonty = 8

            Dim pixel As Color
            For i = 0 To 11
                For j = 0 To 19
                    pixel = fp_font.GetPixel(fontx * 16 + i + 4, fonty * 24 + j)
                    If doubleheight = 0 Then
                        If pixel.ToArgb = -16777216 Then fp_screen.SetPixel(i + x * 12, j + y * 20, thebackcolor)
                        If pixel.ToArgb = -2302756 Then fp_screen.SetPixel(i + x * 12, j + y * 20, theforecolor)
                    Else
                        If pixel.ToArgb = -16777216 Then fp_screen.SetPixel(i + x * 12, j * (doubleheight + 1) + y * 20, thebackcolor)
                        If pixel.ToArgb = -16777216 Then fp_screen.SetPixel(i + x * 12, j * (doubleheight + 1) + y * 20 + 1, thebackcolor)
                        If pixel.ToArgb = -2302756 Then fp_screen.SetPixel(i + x * 12, j * (doubleheight + 1) + y * 20, theforecolor)
                        If pixel.ToArgb = -2302756 Then fp_screen.SetPixel(i + x * 12, j * (doubleheight + 1) + y * 20 + 1, theforecolor)
                    End If
                Next
            Next
        End If

    End Sub





    Private Sub Form1_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown

        If e.KeyCode = Keys.F1 Then Me.AllowTransparency = False

        If e.KeyCode = Keys.F2 Then Me.TransparencyKey = Color.Black

        If e.KeyCode = Keys.Enter And reveal = 0 Then
            reveal = 1 ' for 1 second
            displaypage()
        End If

        If e.KeyCode = Keys.R Or e.KeyCode = Keys.G Or e.KeyCode = Keys.Y Or e.KeyCode = Keys.B Then
            If searchpage.Length = 3 Then searchpage = ""
            If e.KeyCode = Keys.R Then searchpage = redpage
            If e.KeyCode = Keys.G Then searchpage = greenpage
            If e.KeyCode = Keys.Y Then searchpage = yellowpage
            If e.KeyCode = Keys.B Then searchpage = bluepage
            displaypage()
            If searchpage.Length = 3 Then loadpage()
        End If

        If e.KeyCode = Keys.D1 Or e.KeyCode = Keys.D2 Or e.KeyCode = Keys.D3 Or e.KeyCode = Keys.D4 Or e.KeyCode = Keys.D5 Or e.KeyCode = Keys.D6 Or e.KeyCode = Keys.D7 Or e.KeyCode = Keys.D8 Or e.KeyCode = Keys.D9 Or e.KeyCode = Keys.D0 Then
            If searchpage.Length = 3 Then searchpage = ""
            If e.KeyCode = Keys.D1 Then searchpage = searchpage & "1"
            If e.KeyCode = Keys.D2 Then searchpage = searchpage & "2"
            If e.KeyCode = Keys.D3 Then searchpage = searchpage & "3"
            If e.KeyCode = Keys.D4 Then searchpage = searchpage & "4"
            If e.KeyCode = Keys.D5 Then searchpage = searchpage & "5"
            If e.KeyCode = Keys.D6 Then searchpage = searchpage & "6"
            If e.KeyCode = Keys.D7 Then searchpage = searchpage & "7"
            If e.KeyCode = Keys.D8 Then searchpage = searchpage & "8"
            If e.KeyCode = Keys.D9 Then searchpage = searchpage & "9"
            If e.KeyCode = Keys.D0 Then searchpage = searchpage & "0"
            displaypage()
            If searchpage.Length = 3 Then loadpage()
        End If

    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        'My.Computer.Audio.Play("pfc-low.mp3")
        ' privateFonts.AddFontFile("bbcmode7.ttf")
        'Dim font As New System.Drawing.Font(privateFonts.Families(0), 90)

        Me.FormBorderStyle = Windows.Forms.FormBorderStyle.None
        Me.Location = New Point(0, 0)
        Me.Size = SystemInformation.PrimaryMonitorSize
        Me.BackColor = Color.Black
        ' Me.TransparencyKey = Color.Black
        ' Me.AllowTransparency = False


        pb.SizeMode = PictureBoxSizeMode.StretchImage
        pb.Width = Me.Size.Width  'or whatever
        pb.Height = Me.Size.Height
        pb.Top = 0 'or whatever
        pb.Left = 0
        Me.Controls.Add(pb)

        fp_font.Lock() ' lock the font file

        pb.Image = fp_screen.Bitmap


    End Sub

    Sub loaddirectory()

        Dim temppagedata As String = ""
        'get file directory
        Try
            Dim client As New WebClient
            client.Encoding = Encoding.GetEncoding("ISO-8859-1")
            temppagedata = client.DownloadString(teefaxserver)

        Catch
        End Try
        filedirectory = Regex.Replace(temppagedata, "<.*?>", "") ' removes all html tags

    End Sub

    Function fixpage(ByVal temppagedata As String) As String
        temppagedata = temppagedata.Replace(Chr(27) & "@", ChrW(128))
        temppagedata = temppagedata.Replace(Chr(27) & "A", ChrW(129))
        temppagedata = temppagedata.Replace(Chr(27) & "B", ChrW(130))
        temppagedata = temppagedata.Replace(Chr(27) & "C", ChrW(131))
        temppagedata = temppagedata.Replace(Chr(27) & "D", ChrW(132))
        temppagedata = temppagedata.Replace(Chr(27) & "E", ChrW(133))
        temppagedata = temppagedata.Replace(Chr(27) & "F", ChrW(134))
        temppagedata = temppagedata.Replace(Chr(27) & "G", ChrW(135))
        temppagedata = temppagedata.Replace(Chr(27) & "H", ChrW(136))
        temppagedata = temppagedata.Replace(Chr(27) & "I", ChrW(137))
        temppagedata = temppagedata.Replace(Chr(27) & "J", ChrW(138))
        temppagedata = temppagedata.Replace(Chr(27) & "K", ChrW(139))
        temppagedata = temppagedata.Replace(Chr(27) & "L", ChrW(140))
        temppagedata = temppagedata.Replace(Chr(27) & "M", ChrW(141))
        temppagedata = temppagedata.Replace(Chr(27) & "N", ChrW(142))
        temppagedata = temppagedata.Replace(Chr(27) & "O", ChrW(143))
        temppagedata = temppagedata.Replace(Chr(27) & "P", ChrW(144))
        temppagedata = temppagedata.Replace(Chr(27) & "Q", ChrW(145))
        temppagedata = temppagedata.Replace(Chr(27) & "R", ChrW(146))
        temppagedata = temppagedata.Replace(Chr(27) & "S", ChrW(147))
        temppagedata = temppagedata.Replace(Chr(27) & "T", ChrW(148))
        temppagedata = temppagedata.Replace(Chr(27) & "U", ChrW(149))
        temppagedata = temppagedata.Replace(Chr(27) & "V", ChrW(150))
        temppagedata = temppagedata.Replace(Chr(27) & "W", ChrW(151))
        temppagedata = temppagedata.Replace(Chr(27) & "X", ChrW(152))
        temppagedata = temppagedata.Replace(Chr(27) & "Y", ChrW(153))
        temppagedata = temppagedata.Replace(Chr(27) & "Z", ChrW(154))
        temppagedata = temppagedata.Replace(Chr(27) & "[", ChrW(155))
        temppagedata = temppagedata.Replace(Chr(27) & "\", ChrW(156))
        temppagedata = temppagedata.Replace(Chr(27) & "]", ChrW(157))
        temppagedata = temppagedata.Replace(Chr(27) & "^", ChrW(158))
        temppagedata = temppagedata.Replace(Chr(27) & "_", ChrW(159))
        Return temppagedata
    End Function

    Sub loadpage()
        Dim filename As String = ""

        'run through the list to get the filename
        For Each line In filedirectory.Split(Chr(10))
            If line.IndexOf(searchpage) <> -1 Then filename = line.Trim()
        Next

        Dim temppagedata As String = ""
        If filename = "" Then filename = "bad file"
        Try
            Dim client As New WebClient
            client.Encoding = Encoding.GetEncoding("ISO-8859-1")
            temppagedata = client.DownloadString(teefaxserver & filename)
        Catch
            'do nothing
        End Try

        If temppagedata <> "" Then
            'do this to fix the wierd pages
            temppagedata = fixpage(temppagedata)

            pagedata = vbCrLf & temppagedata
            pagelist = ""
            redpage = ""
            greenpage = ""
            yellowpage = ""
            bluepage = ""
            subpage = 0
            Timer2.Stop()
            Timer2.Interval = 10000
            'run through document and get pages list and set the times
            For Each line In pagedata.Split(Chr(10))
                line = line.Replace(Chr(13), "")
                If line.Length > 3 Then
                    If line.Substring(0, 2) = "PN" Then
                        pagelist = pagelist & line.Substring(3, 5).ToUpper() & ","
                    End If
                    If line.Substring(0, 2) = "CT" Then
                        startpos = line.IndexOf(",") + 1
                        endpos = line.IndexOf(",", startpos)
                        Timer2.Interval = line.Substring(startpos, endpos - startpos) * 1000
                    End If
                End If
            Next
            currentpage = searchpage
            Timer2.Start()

            displaypage()

        End If

    End Sub

    Sub displaypage()
        blankscreen()
        fp_screen.Lock()
        Dim line As String = ""
        Dim progressingpage As String = ""
        skipline = -1
        If pagedata <> "" Then

            For Each line In pagedata.Split(Chr(10))
                line = line.Replace(Chr(13), "")

                If line.Length > 3 Then
                    If line.Substring(0, 2) = "PN" Then
                        progressingpage = line.Substring(3, 5).ToUpper()
                    End If
                    If line.Substring(0, 2) = "OL" And progressingpage = pagelist.Split(",")(subpage) Then
                        textprint(line)
                    End If
                    If line.Substring(0, 2) = "FL" And progressingpage = pagelist.Split(",")(subpage) Then
                        startpos = line.IndexOf(",") + 1
                        endpos = line.IndexOf(",", startpos)
                        redpage = line.Substring(startpos, endpos - startpos).ToUpper
                        startpos = line.IndexOf(",", endpos) + 1
                        endpos = line.IndexOf(",", startpos)
                        greenpage = line.Substring(startpos, endpos - startpos).ToUpper
                        startpos = line.IndexOf(",", endpos) + 1
                        endpos = line.IndexOf(",", startpos)
                        yellowpage = line.Substring(startpos, endpos - startpos).ToUpper
                        startpos = line.IndexOf(",", endpos) + 1
                        endpos = line.IndexOf(",", startpos)
                        bluepage = line.Substring(startpos, endpos - startpos).ToUpper
                    End If
                End If
            Next
        End If
        updatetop()
        fp_screen.Unlock(True)
        pb.Refresh()
    End Sub
    Sub blankscreen()
        Using G As Graphics = Graphics.FromImage(img)
            G.Clear(Color.Black)
        End Using
    End Sub
    Sub updatetop()
        'update the firstline from datafile.
        Dim topcursorx As Integer = 0
        Dim pagestring As String = ""

        If searchpage.Length = 0 Then pagestring = " P" & searchpage & "      "
        If searchpage.Length = 1 Then pagestring = " P" & searchpage & "     "
        If searchpage.Length = 2 Then pagestring = " P" & searchpage & "    "
        If searchpage.Length = 3 Then pagestring = " P" & searchpage & "   "

        For Each c As Char In pagestring
            If currentpage <> searchpage Then addchar(topcursorx, 0, AscW(c), Color.Black, Color.Red, 0)
            topcursorx = topcursorx + 1
        Next
    End Sub



    Sub textprint(ByVal theline As String)

        Dim cursorx As Decimal = 0
        Dim cursory As Decimal = 0

        Dim inkcolor As Color = Color.White
        Dim papercolor As Color = Color.Black
        Dim doubleheight As Integer = 0
        Dim specialoffset As Integer = 0
        Dim extraspecial As Integer = 1
        Dim holdmode As Integer = 0
        Dim dontprint As Integer = 0
        Dim dontprintink As Integer = 0
        Dim previouscharacter As Integer = 32


        Dim startpos As Integer = theline.IndexOf(",") + 1
        Dim endpos As Integer = theline.IndexOf(",", startpos)

        If (theline.Substring(startpos, endpos - startpos) <> "" & skipline) Then


            If (theline.Substring(startpos, endpos - startpos) = "0") Then
                If searchpage.Length = 0 Then theline = theline.Replace("XXXXXXXX", " P" & searchpage & "      ")
                If searchpage.Length = 1 Then theline = theline.Replace("XXXXXXXX", " P" & searchpage & "     ")
                If searchpage.Length = 2 Then theline = theline.Replace("XXXXXXXX", " P" & searchpage & "    ")
                If searchpage.Length = 3 Then theline = theline.Replace("XXXXXXXX", " P" & searchpage & "   ")
                theline = theline.Replace("DAY", Format(Now(), "ddd"))
                theline = theline.Replace("dd", Format(Now(), "dd"))
                theline = theline.Replace("MTH", Format(Now(), "MMM"))
                theline = theline.Replace("hh", Format(Now(), "HH"))
                theline = theline.Replace("nn", Format(Now(), "mm"))
                theline = theline.Replace("ss", Format(Now(), "ss"))
                theline = theline.Replace("mpp", currentpage)
            End If

            cursory = theline.Substring(startpos, endpos - startpos)
            cursorx = 0


            '----------------------debug code---------
            'Dim sam As String = ""
            'If theline.IndexOf("EDIT BBS") <> -1 Then
            'For Each neil As Char In theline
            ' sam = sam & "(" & AscW(neil) & ")"
            'Next
            'fp_screen.Unlock(True)
            ' MsgBox(sam)
            'fp_screen.Lock()
            'End If
            '----------------------

            Dim c As Integer
            For pos As Integer = endpos + 1 To theline.Length - 1
                c = AscW(theline.Substring(pos, 1))

                If c = 158 Then holdmode = 1
                If c = 157 Then papercolor = inkcolor
                If c = 156 Then papercolor = Color.Black
                If c = 152 And reveal = 0 Then dontprint = 1 ' this for conceal revealed with button press 

                If c > 127 Then ' for escape codes
                    If dontprint = 0 Then If holdmode = 1 Then addchar(cursorx, cursory, previouscharacter, papercolor, inkcolor, doubleheight)
                    If dontprint = 0 Then If holdmode = 0 Then addchar(cursorx, cursory, 32, papercolor, inkcolor, doubleheight)
                End If

                If c = 159 Then holdmode = 0
                'If c = 128 Then inkcolor = Color.Black : specialoffset = 0 : dontprint = 0 : holdmode = 0
                If c = 129 Then inkcolor = Color.Red : specialoffset = 0 : dontprint = 0 : holdmode = 0
                If c = 130 Then inkcolor = Color.FromArgb(0, 255, 0) : specialoffset = 0 : dontprint = 0 : holdmode = 0
                If c = 131 Then inkcolor = Color.Yellow : specialoffset = 0 : dontprint = 0 : holdmode = 0
                If c = 132 Then inkcolor = Color.Blue : specialoffset = 0 : dontprint = 0 : holdmode = 0
                If c = 133 Then inkcolor = Color.Magenta : specialoffset = 0 : dontprint = 0 : holdmode = 0
                If c = 134 Then inkcolor = Color.Cyan : specialoffset = 0 : dontprint = 0 : holdmode = 0
                If c = 135 Then inkcolor = Color.White : specialoffset = 0 : dontprint = 0 : holdmode = 0
                If c = 136 And flash = 0 Then dontprintink = 1 ' turn on flash
                If c = 137 Then dontprintink = 0 ' turn off flash
                ' If c = AscW("I") ENDBOX
                ' If c = AscW("K") STARTBOX
                If c = 140 Then doubleheight = 0 : holdmode = 0
                If c = 141 Then doubleheight = 1 : holdmode = 0 : duplicateline(theline) : skipline = cursory + 1
                If c = 145 Then inkcolor = Color.Red : specialoffset = 96 : dontprint = 0
                If c = 146 Then inkcolor = Color.FromArgb(0, 255, 0) : specialoffset = 96 : dontprint = 0
                If c = 147 Then inkcolor = Color.Yellow : specialoffset = 96 : dontprint = 0
                If c = 148 Then inkcolor = Color.Blue : specialoffset = 96 : dontprint = 0
                If c = 149 Then inkcolor = Color.Magenta : specialoffset = 96 : dontprint = 0
                If c = 150 Then inkcolor = Color.Cyan : specialoffset = 96 : dontprint = 0
                If c = 151 Then inkcolor = Color.White : specialoffset = 96 : dontprint = 0
                If c = 153 Then extraspecial = 1
                If c = 154 Then extraspecial = 2

                If c < 128 Then 'for characters
                    If dontprint = 0 And dontprintink = 0 Then addchar(cursorx, cursory, c + specialoffset * extraspecial, papercolor, inkcolor, doubleheight)
                    If dontprint = 0 And dontprintink = 1 Then addchar(cursorx, cursory, c + specialoffset * extraspecial, papercolor, papercolor, doubleheight)
                    previouscharacter = c + specialoffset * extraspecial
                End If

                cursorx = cursorx + 1

            Next

            ' blank to end of line if cursor not at end
            If cursorx < 40 Then
                For pos As Integer = cursorx To 40
                    addchar(cursorx, cursory, 32, papercolor, inkcolor, doubleheight)
                    cursorx = cursorx + 1
                Next
            End If

        End If

    End Sub

    Sub duplicateline(ByVal theline)
        Dim c As Integer
        Dim startpos As Integer = theline.IndexOf(",") + 1
        Dim endpos As Integer = theline.IndexOf(",", startpos)
        Dim cursory As Integer = theline.Substring(startpos, endpos - startpos)
        theline = theline.Replace("OL," & cursory & ",", "OL," & cursory + 1 & ",")

        'also remove all characters, leave only escape codes
        startpos = theline.IndexOf(",") + 1
        endpos = theline.IndexOf(",", startpos)
        Dim newstring As String = theline.Substring(0, endpos + 1)
        For pos As Integer = endpos + 1 To theline.Length - 1
            c = AscW(theline.Substring(pos, 1))
            If c > 127 And c <> 141 Then
                newstring = newstring & theline.Substring(pos, 1)
            Else
                newstring = newstring & " "
            End If
        Next

        textprint(newstring)
    End Sub

    Private Sub Timer2_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer2.Tick
        subpage = subpage + 1
        If subpage > (pagelist.Split(",").Length - 1) - 1 Then subpage = 0
        displaypage()
    End Sub

    Private Sub Form1_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles Me.Paint
        loaddirectory()
        loadpage()
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        If flash = 1 Then flash = 0 Else flash = 1
        displaypage()
        If reveal > 0 Then reveal = reveal - 1
    End Sub
End Class
